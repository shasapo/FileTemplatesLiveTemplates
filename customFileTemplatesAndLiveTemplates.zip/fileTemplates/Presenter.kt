#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")
class ${NAME}Impl() : ${Contract_file_name}.Presenter{
var view: ${Contract_file_name}.View? = null


    override fun attachView(view: ${Contract_file_name}.View) {
        this.view = view
    }

    override fun detachView() {
        this.view = null
    }
}
