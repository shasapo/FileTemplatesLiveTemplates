#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

#end
#parse("File Header.java")
class ${NAME} : ListAdapter<${NAME}.$View_object_class_name, RecyclerView.ViewHolder>($Diff_util_name()){

    data class $View_object_class_name (val  id: Int)
    class $View_holder_name(itemView: View) : RecyclerView.ViewHolder(itemView)

    override fun getItemViewType(position: Int): Int {
        return R.layout.$item_layout_name
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
                TODO("Not yet implemented")
        //val itemView = ....
        //return $View_holder_name(itemView)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        TODO("Not yet implemented")
    }

    private class $Diff_util_name : DiffUtil.ItemCallback<$View_object_class_name>() {
        override fun areItemsTheSame(
            oldItem: $View_object_class_name,
            newItem: $View_object_class_name
        ): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(
            oldItem: $View_object_class_name,
            newItem: $View_object_class_name
        ): Boolean {
            return oldItem.hashCode() == newItem.hashCode()
        }
    }

}