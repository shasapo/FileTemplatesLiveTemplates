#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.Adapter

#end
#parse("File Header.java")
class ${NAME} : Adapter<${NAME}.$View_holder_name>(){

    class $View_holder_name(itemView: View) : RecyclerView.ViewHolder(itemView)
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): $View_holder_name {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.$Item_layout_name, parent, false)
        return $View_holder_name(view)
    }

    override fun getItemCount(): Int {
        TODO("Not yet implemented")
    }

    override fun onBindViewHolder(holder: $View_holder_name, position: Int) {
        TODO("Not yet implemented")
    }
}
